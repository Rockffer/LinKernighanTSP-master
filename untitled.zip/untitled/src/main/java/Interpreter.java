import java.io.*;
import java.util.*;

/*
 * @author Rodolfo Pichardo
 * This class read a file in TSP format and converts it into a list of ids and points
 */
public class Interpreter {
    /* 
     * Class variables
     */
    private ArrayList<Integer> id;
    private ArrayList<Point> coordinates; 


	public Interpreter(File file) {
        // Initialize the class variables
        this.id = new ArrayList<Integer>();
        this.coordinates = new ArrayList<Point>();
		try {
			BufferedReader in = new BufferedReader(new FileReader(file));
			String line;
			while((line = in.readLine()) != null) {
				try {
	                Token tokens = getTokens(line);
	                addId(tokens.getId());
	                addPoint(tokens.getPoint());
				} catch(IllegalArgumentException e) {}
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


    private Token getTokens(String line) throws IllegalArgumentException {
        StringTokenizer tokenizer = new StringTokenizer(line);
        try {
            int id = Integer.parseInt(tokenizer.nextToken());
            double x = Double.parseDouble(tokenizer.nextToken());
            double y = Double.parseDouble(tokenizer.nextToken());
            
            if(!tokenizer.hasMoreTokens()) {
                return new Token(id, x, y);
            }

        } catch(Exception e) {}
        throw new IllegalArgumentException();
    }


    private void addId(int id) {
        this.id.add(id);
    }


    private void addPoint(Point pt) {
        this.coordinates.add(pt);
    }

    public ArrayList<Integer> getIds() {
        return this.id;
    }

    public ArrayList<Point> getCoordinates() {
        return this.coordinates;
    }


}