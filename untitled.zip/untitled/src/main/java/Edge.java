import java.util.*;

/**
 *此类用于表示边缘，它允许存储
 * 端点 ID 并比较边缘
 */
public class Edge implements Comparable<Edge> {
    /*
     * Instance variables
     */

    // The first node
    private int endPoint1;
    
    // The second node
    private int endPoint2;

    /**
     * 采用两个端点 id 的构造函数
     * @param int 第一个端点的 id
     * @param int 第二个端点的 id
     */
    public Edge(int a, int b) {
        this.endPoint1 = a > b? a:b;
        this.endPoint2 = a > b? b:a;
    }

    /**
     * 返回第一个端点 ID 的 getter
     * @param
     * @return第一个端点 ID
     */
    public int get1() {
        return this.endPoint1;
    }

    /**
     * 返回第二个端点 ID 的 getter
     * @param
     * @return第二个端点 ID
     */
    public int get2() {
        return this.endPoint2;
    }


    public int compareTo(Edge e2) {
        if(this.get1() < e2.get1() || this.get1() == e2.get1() && this.get2() < e2.get2()) {
            return -1;
        } else if (this.equals(e2)) {
            return 0;
        } else {
            return 1;
        }

    }


    public boolean equals(Edge e2) {
    	if(e2 == null) return false;
        return (this.get1() == e2.get1()) && (this.get2() == e2.get2());
    }
    
    public String toString() {
    	return "("+ endPoint1 + ", " + endPoint2 + ")";
    }

}