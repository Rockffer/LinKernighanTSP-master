
class Token {
    /*
     * Instance variables
     */

    // The id of the point / city
    private int id;

    // The coordinates of the point
    private Point point;


    public Token(int id, double x, double y) {
        this.id = id;
        this.point = new Point(x, y);
    }

    public int getId() {
        return this.id;
    }


    public Point getPoint() {
        return this.point;
    }

}